from django.db import models
from django.core.urlresolvers import reverse
import csv

data = []
with open('./contacts/data_u-2012.csv' , 'r') as csvfile :
	reader = csv.reader(csvfile)
	for row in reader :
		data.append(row)

for x in range(len(data)):
	data[x][0] = data[x][2] +"-"+ data[x][0]+"-" + data[x][1]



YEAR_IN_SCHOOL_CHOICES = (
	('FR', 'Freshman'),
	('SO', 'Sophomore'),
	('JR', 'Junior'),
	('SR', 'Senior'),
)

class Contact(models.Model):
	progs = [''] * len(data)

	PROGRAMME_CHOICES =()
	for x in range(len(progs)):
		PROGRAMME_CHOICES = ((progs[x], data[x][0]),) + PROGRAMME_CHOICES
	PROGRAMME_CHOICES = PROGRAMME_CHOICES[::-1]

	programme = models.CharField( 
		max_length=6,choices=PROGRAMME_CHOICES,
		default='B4110')

	def get_absolute_url(self):
		return reverse('contacts-view', kwargs={'pk': self.id})

